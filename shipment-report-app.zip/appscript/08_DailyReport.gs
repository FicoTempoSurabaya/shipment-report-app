/**
 * SETRA - Daily Report / Report Performance Automation
 * File: 08_DailyReport.gs
 * Scope: rebuild sheet "Daily_Report" dari sheet "shipments" dan "users".
 */

const SETRA_DAILY_REPORT = Object.freeze({
  SHIPMENTS_SHEET_NAME: 'shipments',
  USERS_SHEET_NAME: 'users',
  REPORT_SHEET_NAME: 'Daily_Report',

  START_DATE_A1: 'C1',
  END_DATE_A1: 'C2',

  HEADER_START_ROW: 4,
  FREEZE_ROW: 8,
  DATA_START_ROW: 9,
  DATA_END_ROW: 39,

  SUMMARY_ROW: 41,
  DETAIL_START_ROW: 43,
  DETAIL_END_ROW: 55,

  STATIC_START_COL: 2, // B
  DATE_COL: 3, // C
  START_COL: 11, // K
  BLOCK_WIDTH: 5,

  SUNDAY_ROW_BACKGROUND: '#ea4335',
  DEFAULT_ROW_BACKGROUND: '#ffffff',
  HEADER_BACKGROUND: '#7EA6E0',
  PERCENT_BACKGROUND: '#C6E0B4',

  SHIPMENT_NUMBER_FORMAT: '@',
  MAX_RANGE_DAYS: 31,

  SUB_HEADERS: ['HKA', 'JT', 'ATT', '%', 'SHIPMENT'],

  DROPDOWN_VALUES: [
    'OFF',
    'A',
    'I',
    'C',
    'S',
    'R',
    'LODING SORE',
    'STANBAY',
    'KIUR UNIT',
    'SERVICE',
    'KIRIM ULANG',
    'SO',
    'LIBUR NASIONAL',
  ],

  NON_HKA_VALUES: [
    'OFF',
    'A',
    'I',
    'C',
    'S',
    'R',
    'LIBUR NASIONAL',
  ],

  DIA_VALUES: ['A', 'I', 'C', 'S', 'R'],

  SHIPMENT_DETAIL_VALUES: [
    'A',
    'I',
    'C',
    'S',
    'R',
    'LODING SORE',
    'STANBAY',
    'KIUR UNIT',
    'SERVICE',
    'KIRIM ULANG',
    'SO',
    'LIBUR NASIONAL',
  ],

  STATUS_DISPLAY_MAP: Object.freeze({
    'SAKIT': 'S',
    'IZIN': 'I',
    'ALPHA': 'A',
    'CUTI': 'C',
    'SO': 'SO',
    'SERVICE': 'SERVICE',
    'LOADING SORE': 'LODING SORE',
    'LODING SORE': 'LODING SORE',
    'STANDBY': 'STANBAY',
    'STANBAY': 'STANBAY',
    'KIUR UNIT': 'KIUR UNIT',
    'KIRIM ULANG': 'KIRIM ULANG',
    'LIBUR NASIONAL': 'LIBUR NASIONAL',
  }),
});

function setraProcessDailyReport() {
  const lock = LockService.getDocumentLock();

  if (!lock.tryLock(30000)) {
    SpreadsheetApp.getUi().alert('Setra sedang menjalankan proses lain. Coba lagi setelah proses sebelumnya selesai.');
    return;
  }

  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const targetSheet = setraDailyReportGetRequiredSheet_(ss, SETRA_DAILY_REPORT.REPORT_SHEET_NAME);
    const timezone = setraGetTimezone_();
    const dateRange = setraDailyReportValidateDates_(targetSheet, timezone);
    const dates = setraDailyReportBuildDateList_(dateRange.startDate, dateRange.endDate);
    const participants = setraDailyReportGetParticipants_(ss);

    if (participants.length === 0) {
      throw new Error('Tidak ada user/participant valid dari sheet users atau shipments. Jalankan fetching users/shipments terlebih dahulu.');
    }

    const shipmentsMap = setraDailyReportBuildShipmentsMap_(ss, participants, timezone);
    const totalCols = participants.length * SETRA_DAILY_REPORT.BLOCK_WIDTH;
    const neededLastCol = SETRA_DAILY_REPORT.START_COL + totalCols - 1;

    setraDailyReportPrepareColumns_(targetSheet, neededLastCol);
    setraDailyReportBuildStaticDates_(targetSheet, dates, participants.length, neededLastCol);
    setraDailyReportBuildHeader_(targetSheet, participants);
    setraDailyReportBuildData_(targetSheet, dates, participants, shipmentsMap, timezone, neededLastCol);
    setraDailyReportBuildSummary_(targetSheet, participants.length);

    ss.toast('Report_Performance selesai diperbarui.', 'Setra', 5);
    setraShowResultDialog_('Report_Performance', [
      ['Participant', participants.length],
      ['Jumlah tanggal', dates.length],
      ['Sheet sumber', SETRA_DAILY_REPORT.SHIPMENTS_SHEET_NAME],
      ['Sheet output', SETRA_DAILY_REPORT.REPORT_SHEET_NAME],
    ], 'Daily_Report berhasil diproses dari data shipments.');
  } catch (error) {
    SpreadsheetApp.getActiveSpreadsheet().toast('Report_Performance gagal.', 'Setra', 8);
    setraShowResultDialog_('Report_Performance Gagal', [
      ['Status', 'FAILED'],
    ], error && error.message ? error.message : String(error));
    throw error;
  } finally {
    lock.releaseLock();
  }
}

function setraDailyReportValidateDates_(sheet, timezone) {
  const startDate = setraDailyReportNormalizeDate_(sheet.getRange(SETRA_DAILY_REPORT.START_DATE_A1).getValue(), timezone);
  const endDate = setraDailyReportNormalizeDate_(sheet.getRange(SETRA_DAILY_REPORT.END_DATE_A1).getValue(), timezone);

  if (!startDate || !endDate) {
    throw new Error('Tanggal awal C1 dan tanggal akhir C2 pada Daily_Report wajib berupa tanggal valid.');
  }

  if (endDate.getTime() < startDate.getTime()) {
    throw new Error('Tanggal akhir C2 tidak boleh lebih kecil dari tanggal awal C1.');
  }

  const dayCount = setraDailyReportDiffDaysInclusive_(startDate, endDate);
  if (dayCount > SETRA_DAILY_REPORT.MAX_RANGE_DAYS) {
    throw new Error('Rentang Daily_Report maksimal ' + SETRA_DAILY_REPORT.MAX_RANGE_DAYS + ' hari. Rentang saat ini ' + dayCount + ' hari.');
  }

  return { startDate: startDate, endDate: endDate, dayCount: dayCount };
}

function setraDailyReportPrepareColumns_(sheet, neededLastCol) {
  const maxCols = sheet.getMaxColumns();

  if (maxCols < neededLastCol) {
    sheet.insertColumnsAfter(maxCols, neededLastCol - maxCols);
  }

  const clearLastCol = Math.max(sheet.getMaxColumns(), neededLastCol);
  const clearColCount = clearLastCol - SETRA_DAILY_REPORT.START_COL + 1;

  if (clearColCount > 0) {
    sheet
      .getRange(SETRA_DAILY_REPORT.HEADER_START_ROW, SETRA_DAILY_REPORT.START_COL, SETRA_DAILY_REPORT.DETAIL_END_ROW - SETRA_DAILY_REPORT.HEADER_START_ROW + 1, clearColCount)
      .breakApart()
      .clearContent()
      .clearFormat()
      .clearDataValidations();
  }
}

function setraDailyReportBuildStaticDates_(sheet, dates, participantCount, neededLastCol) {
  const rowCount = SETRA_DAILY_REPORT.DATA_END_ROW - SETRA_DAILY_REPORT.DATA_START_ROW + 1;
  const values = [];
  const dynamicRefs = setraDailyReportBuildDynamicColumnRefs_(participantCount);

  for (let i = 0; i < rowCount; i += 1) {
    const rowNumber = SETRA_DAILY_REPORT.DATA_START_ROW + i;
    const date = dates[i] || null;

    if (!date) {
      values.push([i + 1, '', '', '', '', '', '', '']);
      continue;
    }

    const hkaFormula = dynamicRefs.hkaCells.length > 0 ? '=SUM(' + dynamicRefs.hkaCells.map(function (col) { return col + rowNumber; }).join(';') + ')' : '';
    const diaFormula = dynamicRefs.shipmentRangeStart && dynamicRefs.shipmentRangeEnd
      ? '=SUM(' + SETRA_DAILY_REPORT.DIA_VALUES.map(function (value) { return 'COUNTIF(' + dynamicRefs.shipmentRangeStart + rowNumber + ':' + dynamicRefs.shipmentRangeEnd + rowNumber + ';"' + value + '")'; }).join(';') + ')'
      : '';
    const jtFormula = dynamicRefs.jtCells.length > 0 ? '=SUM(' + dynamicRefs.jtCells.map(function (col) { return col + rowNumber; }).join(';') + ')' : '';
    const attFormula = dynamicRefs.attCells.length > 0 ? '=SUM(' + dynamicRefs.attCells.map(function (col) { return col + rowNumber; }).join(';') + ')' : '';
    const percentFormula = '=IFERROR(H' + rowNumber + '/G' + rowNumber + ';"")';

    values.push([
      i + 1,
      date,
      setraDailyReportDayNameId_(date),
      hkaFormula,
      diaFormula,
      jtFormula,
      attFormula,
      percentFormula,
    ]);
  }

  sheet.getRange(SETRA_DAILY_REPORT.DATA_START_ROW, 2, rowCount, 8)
    .clearContent()
    .clearDataValidations()
    .setValues(values)
    .setHorizontalAlignment('center')
    .setVerticalAlignment('middle')
    .setFontSize(9)
    .setBorder(true, true, true, true, true, true);

  sheet.getRange(SETRA_DAILY_REPORT.DATA_START_ROW, SETRA_DAILY_REPORT.DATE_COL, rowCount, 1).setNumberFormat('d-mmm-yy');
  sheet.getRange(SETRA_DAILY_REPORT.DATA_START_ROW, 5, rowCount, 4).setNumberFormat('0');
  sheet.getRange(SETRA_DAILY_REPORT.DATA_START_ROW, 9, rowCount, 1).setNumberFormat('0.00%');

  sheet.getRange(SETRA_DAILY_REPORT.SUMMARY_ROW, 2, 1, 8)
    .clearContent()
    .setValues([[
      'TOTAL',
      '',
      '',
      '=SUM(E' + SETRA_DAILY_REPORT.DATA_START_ROW + ':E' + SETRA_DAILY_REPORT.DATA_END_ROW + ')',
      '=SUM(F' + SETRA_DAILY_REPORT.DATA_START_ROW + ':F' + SETRA_DAILY_REPORT.DATA_END_ROW + ')',
      '=SUM(G' + SETRA_DAILY_REPORT.DATA_START_ROW + ':G' + SETRA_DAILY_REPORT.DATA_END_ROW + ')',
      '=SUM(H' + SETRA_DAILY_REPORT.DATA_START_ROW + ':H' + SETRA_DAILY_REPORT.DATA_END_ROW + ')',
      '=IFERROR(H' + SETRA_DAILY_REPORT.SUMMARY_ROW + '/G' + SETRA_DAILY_REPORT.SUMMARY_ROW + ';"")',
    ]])
    .setHorizontalAlignment('center')
    .setVerticalAlignment('middle')
    .setFontWeight('bold')
    .setFontSize(9)
    .setBorder(true, true, true, true, true, true);

  sheet.getRange(SETRA_DAILY_REPORT.SUMMARY_ROW, 5, 1, 4).setNumberFormat('0');
  sheet.getRange(SETRA_DAILY_REPORT.SUMMARY_ROW, 9).setNumberFormat('0.00%');

  sheet.setFrozenRows(SETRA_DAILY_REPORT.FREEZE_ROW);
}

function setraDailyReportBuildHeader_(targetSheet, participants) {
  const totalCols = participants.length * SETRA_DAILY_REPORT.BLOCK_WIDTH;

  participants.forEach(function (participant, index) {
    const col = SETRA_DAILY_REPORT.START_COL + index * SETRA_DAILY_REPORT.BLOCK_WIDTH;

    const nikRange = targetSheet.getRange(SETRA_DAILY_REPORT.HEADER_START_ROW, col, 1, SETRA_DAILY_REPORT.BLOCK_WIDTH);
    const namaRange = targetSheet.getRange(SETRA_DAILY_REPORT.HEADER_START_ROW + 1, col, 1, SETRA_DAILY_REPORT.BLOCK_WIDTH);
    const jabatanRange = targetSheet.getRange(SETRA_DAILY_REPORT.HEADER_START_ROW + 2, col, 1, SETRA_DAILY_REPORT.BLOCK_WIDTH);
    const subHeaderRange = targetSheet.getRange(SETRA_DAILY_REPORT.HEADER_START_ROW + 3, col, 1, SETRA_DAILY_REPORT.BLOCK_WIDTH);

    nikRange.merge().setValue(participant.nik || '');
    namaRange.merge().setValue(participant.nama || '');
    jabatanRange.merge().setValue(participant.jabatan || '');
    subHeaderRange.setValues([SETRA_DAILY_REPORT.SUB_HEADERS]);

    targetSheet
      .getRange(SETRA_DAILY_REPORT.HEADER_START_ROW, col, 4, SETRA_DAILY_REPORT.BLOCK_WIDTH)
      .setHorizontalAlignment('center')
      .setVerticalAlignment('middle')
      .setFontSize(9)
      .setBorder(true, true, true, true, true, true);

    targetSheet
      .getRange(SETRA_DAILY_REPORT.HEADER_START_ROW, col, 4, SETRA_DAILY_REPORT.BLOCK_WIDTH)
      .setFontWeight('bold')
      .setBackground(SETRA_DAILY_REPORT.HEADER_BACKGROUND);

    targetSheet
      .getRange(SETRA_DAILY_REPORT.HEADER_START_ROW + 3, col + 3)
      .setBackground(SETRA_DAILY_REPORT.PERCENT_BACKGROUND);

    targetSheet.setColumnWidths(col, 3, 42);
    targetSheet.setColumnWidth(col + 3, 46);
    targetSheet.setColumnWidth(col + 4, 115);
  });

  if (totalCols > 0) {
    targetSheet.setRowHeights(SETRA_DAILY_REPORT.HEADER_START_ROW, 4, 22);
  }

  targetSheet.setFrozenRows(SETRA_DAILY_REPORT.FREEZE_ROW);
}

function setraDailyReportBuildData_(targetSheet, dates, participants, shipmentsMap, timezone, neededLastCol) {
  const totalCols = participants.length * SETRA_DAILY_REPORT.BLOCK_WIDTH;
  const rowCount = dates.length;
  const fixedRowCount = SETRA_DAILY_REPORT.DATA_END_ROW - SETRA_DAILY_REPORT.DATA_START_ROW + 1;

  targetSheet
    .getRange(SETRA_DAILY_REPORT.DATA_START_ROW, SETRA_DAILY_REPORT.START_COL, fixedRowCount, totalCols)
    .clearContent()
    .clearFormat()
    .clearDataValidations();

  setraDailyReportResetRowBackground_(targetSheet, SETRA_DAILY_REPORT.DATA_START_ROW, fixedRowCount, SETRA_DAILY_REPORT.STATIC_START_COL, neededLastCol);
  setraDailyReportApplyShipmentDropdown_(targetSheet, participants.length, rowCount);

  const output = [];
  const filledShipmentCells = [];
  const sundayRows = [];

  dates.forEach(function (date, rowIndex) {
    const sheetRow = SETRA_DAILY_REPORT.DATA_START_ROW + rowIndex;
    const dateKey = setraDailyReportDateKey_(date, timezone);
    const isSunday = date.getDay() === 0;
    const rowOutput = [];

    if (isSunday) {
      sundayRows.push(sheetRow);
    }

    participants.forEach(function (participant, participantIndex) {
      const blockStartCol = SETRA_DAILY_REPORT.START_COL + participantIndex * SETRA_DAILY_REPORT.BLOCK_WIDTH;
      const jtCol = blockStartCol + 1;
      const attCol = blockStartCol + 2;
      const shipmentCol = blockStartCol + 4;

      const jtA1 = setraDailyReportCellA1_(sheetRow, jtCol);
      const attA1 = setraDailyReportCellA1_(sheetRow, attCol);
      const shipmentA1 = setraDailyReportCellA1_(sheetRow, shipmentCol);

      let shipmentValue = '';
      let jtValue = '';
      let attValue = '';

      if (isSunday) {
        shipmentValue = 'OFF';
      } else {
        const key = setraDailyReportMakeShipmentKey_(participant.key, dateKey);
        const shipmentData = shipmentsMap[key];

        if (shipmentData) {
          if (shipmentData.shipmentValues.length > 0) {
            shipmentValue = shipmentData.shipmentValues.join(' / ');
            filledShipmentCells.push(shipmentA1);
          }

          if (shipmentData.hasJumlahToko) {
            jtValue = shipmentData.jumlahToko;
          }

          if (shipmentData.hasTerkirim) {
            attValue = shipmentData.terkirim;
          }
        }
      }

      rowOutput.push(
        setraDailyReportBuildHkaFormula_(shipmentA1),
        jtValue,
        attValue,
        '=IFERROR(' + attA1 + '/' + jtA1 + ';"")',
        shipmentValue
      );
    });

    output.push(rowOutput);
  });

  if (output.length > 0) {
    targetSheet
      .getRange(SETRA_DAILY_REPORT.DATA_START_ROW, SETRA_DAILY_REPORT.START_COL, output.length, totalCols)
      .setValues(output)
      .setHorizontalAlignment('center')
      .setVerticalAlignment('middle')
      .setFontSize(9)
      .setBorder(true, true, true, true, true, true);
  }

  setraDailyReportClearDataValidationForCells_(targetSheet, filledShipmentCells);
  setraDailyReportFormatData_(targetSheet, participants.length);
  setraDailyReportApplySundayRowBackground_(targetSheet, sundayRows, SETRA_DAILY_REPORT.DATA_START_ROW, fixedRowCount, SETRA_DAILY_REPORT.STATIC_START_COL, neededLastCol);
}

function setraDailyReportBuildSummary_(targetSheet, participantCount) {
  const totalCols = participantCount * SETRA_DAILY_REPORT.BLOCK_WIDTH;

  targetSheet
    .getRange(SETRA_DAILY_REPORT.SUMMARY_ROW, SETRA_DAILY_REPORT.START_COL, 1, totalCols)
    .clearContent()
    .clearFormat()
    .clearDataValidations();

  targetSheet
    .getRange(SETRA_DAILY_REPORT.DETAIL_START_ROW, SETRA_DAILY_REPORT.START_COL, SETRA_DAILY_REPORT.DETAIL_END_ROW - SETRA_DAILY_REPORT.DETAIL_START_ROW + 1, totalCols)
    .clearContent()
    .clearFormat()
    .clearDataValidations();

  for (let i = 0; i < participantCount; i += 1) {
    const blockStartCol = SETRA_DAILY_REPORT.START_COL + i * SETRA_DAILY_REPORT.BLOCK_WIDTH;
    const hkaCol = blockStartCol;
    const jtCol = blockStartCol + 1;
    const attCol = blockStartCol + 2;
    const percentCol = blockStartCol + 3;
    const shipmentCol = blockStartCol + 4;

    const hkaLetter = setraDailyReportColToLetter_(hkaCol);
    const jtLetter = setraDailyReportColToLetter_(jtCol);
    const attLetter = setraDailyReportColToLetter_(attCol);
    const percentLetter = setraDailyReportColToLetter_(percentCol);
    const shipmentLetter = setraDailyReportColToLetter_(shipmentCol);

    const hkaSummaryCell = setraDailyReportCellA1_(SETRA_DAILY_REPORT.SUMMARY_ROW, hkaCol);
    const jtSummaryCell = setraDailyReportCellA1_(SETRA_DAILY_REPORT.SUMMARY_ROW, jtCol);
    const attSummaryCell = setraDailyReportCellA1_(SETRA_DAILY_REPORT.SUMMARY_ROW, attCol);
    const percentSummaryCell = setraDailyReportCellA1_(SETRA_DAILY_REPORT.SUMMARY_ROW, percentCol);
    const shipmentSummaryCell = setraDailyReportCellA1_(SETRA_DAILY_REPORT.SUMMARY_ROW, shipmentCol);

    targetSheet.getRange(hkaSummaryCell).setFormula('=SUM(' + hkaLetter + SETRA_DAILY_REPORT.DATA_START_ROW + ':' + hkaLetter + SETRA_DAILY_REPORT.DATA_END_ROW + ')');
    targetSheet.getRange(jtSummaryCell).setFormula('=SUM(' + jtLetter + SETRA_DAILY_REPORT.DATA_START_ROW + ':' + jtLetter + SETRA_DAILY_REPORT.DATA_END_ROW + ')');
    targetSheet.getRange(attSummaryCell).setFormula('=SUM(' + attLetter + SETRA_DAILY_REPORT.DATA_START_ROW + ':' + attLetter + SETRA_DAILY_REPORT.DATA_END_ROW + ')');
    targetSheet.getRange(percentSummaryCell).setFormula('=IFERROR(' + attSummaryCell + '/' + jtSummaryCell + ';"")');
    targetSheet.getRange(shipmentSummaryCell).setFormula('=SUMPRODUCT(IFERROR(REGEXMATCH(TO_TEXT(' + shipmentLetter + SETRA_DAILY_REPORT.DATA_START_ROW + ':' + shipmentLetter + SETRA_DAILY_REPORT.DATA_END_ROW + ');"^\\d{10}$")*1;0))');

    targetSheet.getRange(SETRA_DAILY_REPORT.DETAIL_START_ROW, shipmentCol).setFormula('=' + shipmentSummaryCell);

    SETRA_DAILY_REPORT.SHIPMENT_DETAIL_VALUES.forEach(function (value, detailIndex) {
      const row = SETRA_DAILY_REPORT.DETAIL_START_ROW + 1 + detailIndex;
      if (row > SETRA_DAILY_REPORT.DETAIL_END_ROW) return;

      targetSheet.getRange(row, shipmentCol).setFormula('=COUNTIF(' + shipmentLetter + '$' + SETRA_DAILY_REPORT.DATA_START_ROW + ':' + shipmentLetter + '$' + SETRA_DAILY_REPORT.DATA_END_ROW + ';"' + value + '")');
    });

    targetSheet
      .getRange(SETRA_DAILY_REPORT.SUMMARY_ROW, blockStartCol, 1, SETRA_DAILY_REPORT.BLOCK_WIDTH)
      .setHorizontalAlignment('center')
      .setVerticalAlignment('middle')
      .setFontWeight('bold')
      .setFontSize(9)
      .setBorder(true, true, true, true, true, true);

    targetSheet
      .getRange(SETRA_DAILY_REPORT.DETAIL_START_ROW, shipmentCol, SETRA_DAILY_REPORT.DETAIL_END_ROW - SETRA_DAILY_REPORT.DETAIL_START_ROW + 1, 1)
      .setHorizontalAlignment('center')
      .setVerticalAlignment('middle')
      .setFontSize(9)
      .setBorder(true, true, true, true, true, true);

    targetSheet.getRange(SETRA_DAILY_REPORT.SUMMARY_ROW, hkaCol, 1, 3).setNumberFormat('0');
    targetSheet.getRange(SETRA_DAILY_REPORT.SUMMARY_ROW, percentCol).setNumberFormat('0.00%');
    targetSheet.getRange(SETRA_DAILY_REPORT.SUMMARY_ROW, shipmentCol).setNumberFormat('0');
    targetSheet.getRange(SETRA_DAILY_REPORT.DETAIL_START_ROW, shipmentCol, SETRA_DAILY_REPORT.DETAIL_END_ROW - SETRA_DAILY_REPORT.DETAIL_START_ROW + 1, 1).setNumberFormat('0');
  }
}

function setraDailyReportGetParticipants_(ss) {
  const participantsByKey = {};
  const areaId = setraDailyReportGetAreaIdSafe_();

  const usersSheet = ss.getSheetByName(SETRA_DAILY_REPORT.USERS_SHEET_NAME);
  if (usersSheet && usersSheet.getLastRow() >= 2) {
    const payload = setraDailyReportReadSheetPayload_(usersSheet);
    payload.rows.forEach(function (item) {
      const row = item.row;
      const display = item.display;
      const nik = setraDailyReportText_(display[payload.map.nik_kerja]);
      const nama = setraDailyReportName_(display[payload.map.nama_lengkap]);
      const jabatan = setraDailyReportText_(display[payload.map.jabatan]);
      const rowAreaId = payload.map.area_id !== undefined ? setraDailyReportText_(display[payload.map.area_id]) : '';
      const isActive = payload.map.is_active !== undefined ? row[payload.map.is_active] : true;

      if (!nik || !nama) return;
      if (areaId && rowAreaId && rowAreaId !== areaId) return;
      if (setraDailyReportIsFalse_(isActive)) return;

      setraDailyReportAddParticipant_(participantsByKey, {
        type: 'regular',
        key: 'REGULAR::' + nik,
        nik: nik,
        nama: nama,
        jabatan: jabatan || 'REGULAR',
      });
    });
  }

  const shipmentsSheet = ss.getSheetByName(SETRA_DAILY_REPORT.SHIPMENTS_SHEET_NAME);
  if (shipmentsSheet && shipmentsSheet.getLastRow() >= 2) {
    const payload = setraDailyReportReadSheetPayload_(shipmentsSheet);
    payload.rows.forEach(function (item) {
      const display = item.display;
      const statusKerja = payload.map.status_kerja !== undefined ? setraDailyReportKey_(display[payload.map.status_kerja]) : '';
      const nik = payload.map.nik_kerja !== undefined ? setraDailyReportText_(display[payload.map.nik_kerja]) : '';
      const namaLengkap = payload.map.nama_lengkap !== undefined ? setraDailyReportName_(display[payload.map.nama_lengkap]) : '';
      const namaFreelance = payload.map.nama_freelance !== undefined ? setraDailyReportName_(display[payload.map.nama_freelance]) : '';
      const rowAreaId = payload.map.area_id !== undefined ? setraDailyReportText_(display[payload.map.area_id]) : '';

      if (areaId && rowAreaId && rowAreaId !== areaId) return;

      if (statusKerja === 'freelance' || namaFreelance) {
        const name = namaFreelance || namaLengkap;
        if (!name) return;
        setraDailyReportAddParticipant_(participantsByKey, {
          type: 'freelance',
          key: 'FREELANCE::' + setraDailyReportKey_(name),
          nik: '',
          nama: name,
          jabatan: 'FREELANCE',
        });
        return;
      }

      const regularName = namaLengkap;
      if (!regularName) return;
      setraDailyReportAddParticipant_(participantsByKey, {
        type: 'regular',
        key: nik ? 'REGULAR::' + nik : 'REGULAR_NAME::' + setraDailyReportKey_(regularName),
        nik: nik,
        nama: regularName,
        jabatan: 'REGULAR',
      });
    });
  }

  return Object.keys(participantsByKey)
    .map(function (key) { return participantsByKey[key]; })
    .sort(function (a, b) {
      if (a.type !== b.type) return a.type === 'regular' ? -1 : 1;
      if (a.type === 'regular') {
        const left = a.nik || a.nama;
        const right = b.nik || b.nama;
        return left.localeCompare(right, 'id', { numeric: true, sensitivity: 'base' });
      }
      return a.nama.localeCompare(b.nama, 'id', { numeric: true, sensitivity: 'base' });
    });
}

function setraDailyReportAddParticipant_(map, participant) {
  if (!participant || !participant.key || !participant.nama) return;

  if (!map[participant.key]) {
    map[participant.key] = participant;
    return;
  }

  if (!map[participant.key].jabatan || map[participant.key].jabatan === 'REGULAR') {
    map[participant.key].jabatan = participant.jabatan || map[participant.key].jabatan;
  }
}

function setraDailyReportBuildShipmentsMap_(ss, participants, timezone) {
  const participantLookup = {};
  participants.forEach(function (participant) {
    participantLookup[participant.key] = participant;
    if (participant.type === 'regular' && participant.nik) {
      participantLookup['REGULAR::' + participant.nik] = participant;
    }
    if (participant.type === 'regular' && participant.nama) {
      participantLookup['REGULAR_NAME::' + setraDailyReportKey_(participant.nama)] = participant;
    }
    if (participant.type === 'freelance' && participant.nama) {
      participantLookup['FREELANCE::' + setraDailyReportKey_(participant.nama)] = participant;
    }
  });

  const sheet = setraDailyReportGetRequiredSheet_(ss, SETRA_DAILY_REPORT.SHIPMENTS_SHEET_NAME);
  const payload = setraDailyReportReadSheetPayload_(sheet);
  const result = {};
  const areaId = setraDailyReportGetAreaIdSafe_();

  payload.rows.forEach(function (item) {
    const row = item.row;
    const display = item.display;
    const rowAreaId = payload.map.area_id !== undefined ? setraDailyReportText_(display[payload.map.area_id]) : '';
    const statusKerja = payload.map.status_kerja !== undefined ? setraDailyReportKey_(display[payload.map.status_kerja]) : '';
    const nik = payload.map.nik_kerja !== undefined ? setraDailyReportText_(display[payload.map.nik_kerja]) : '';
    const namaLengkap = payload.map.nama_lengkap !== undefined ? setraDailyReportName_(display[payload.map.nama_lengkap]) : '';
    const namaFreelance = payload.map.nama_freelance !== undefined ? setraDailyReportName_(display[payload.map.nama_freelance]) : '';
    const rawDate = payload.map.tanggal_shipment !== undefined ? row[payload.map.tanggal_shipment] : '';
    const dateKey = setraDailyReportDateKey_(rawDate, timezone);

    if (areaId && rowAreaId && rowAreaId !== areaId) return;
    if (!dateKey) return;

    let participantKey = '';
    if (statusKerja === 'freelance' || namaFreelance) {
      const name = namaFreelance || namaLengkap;
      if (!name) return;
      participantKey = 'FREELANCE::' + setraDailyReportKey_(name);
    } else if (nik) {
      participantKey = 'REGULAR::' + nik;
    } else if (namaLengkap) {
      participantKey = 'REGULAR_NAME::' + setraDailyReportKey_(namaLengkap);
    }

    const participant = participantLookup[participantKey];
    if (!participant) return;

    const key = setraDailyReportMakeShipmentKey_(participant.key, dateKey);
    if (!result[key]) {
      result[key] = {
        shipmentValues: [],
        shipmentKeys: {},
        jumlahToko: 0,
        terkirim: 0,
        hasJumlahToko: false,
        hasTerkirim: false,
      };
    }

    const record = result[key];
    const shipmentValue = payload.map.shipment_code !== undefined
      ? setraDailyReportNormalizeShipmentDisplay_(display[payload.map.shipment_code])
      : '';

    if (shipmentValue && !record.shipmentKeys[shipmentValue]) {
      record.shipmentValues.push(shipmentValue);
      record.shipmentKeys[shipmentValue] = true;
    }

    const jumlahTokoRaw = payload.map.jumlah_toko !== undefined ? row[payload.map.jumlah_toko] : '';
    const terkirimRaw = payload.map.terkirim !== undefined ? row[payload.map.terkirim] : '';

    if (setraDailyReportIsNumeric_(jumlahTokoRaw)) {
      record.jumlahToko += setraDailyReportToNumber_(jumlahTokoRaw);
      record.hasJumlahToko = true;
    }

    if (setraDailyReportIsNumeric_(terkirimRaw)) {
      record.terkirim += setraDailyReportToNumber_(terkirimRaw);
      record.hasTerkirim = true;
    }
  });

  return result;
}

function setraDailyReportReadSheetPayload_(sheet) {
  const lastRow = sheet.getLastRow();
  const lastCol = sheet.getLastColumn();
  const values = lastRow > 0 && lastCol > 0 ? sheet.getRange(1, 1, lastRow, lastCol).getValues() : [];
  const displays = lastRow > 0 && lastCol > 0 ? sheet.getRange(1, 1, lastRow, lastCol).getDisplayValues() : [];
  const headers = (displays[0] || []).map(function (value) { return setraDailyReportHeaderKey_(value); });
  const map = {};

  headers.forEach(function (header, index) {
    if (header) map[header] = index;
  });

  return {
    map: map,
    rows: values.slice(1).map(function (row, index) {
      return {
        row: row,
        display: displays[index + 1],
      };
    }),
  };
}

function setraDailyReportBuildDateList_(startDate, endDate) {
  const dates = [];
  const current = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate());
  const end = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate());

  while (current.getTime() <= end.getTime()) {
    dates.push(new Date(current.getFullYear(), current.getMonth(), current.getDate()));
    current.setDate(current.getDate() + 1);
  }

  return dates;
}

function setraDailyReportBuildDynamicColumnRefs_(participantCount) {
  const hkaCells = [];
  const jtCells = [];
  const attCells = [];
  let shipmentRangeStart = '';
  let shipmentRangeEnd = '';

  for (let i = 0; i < participantCount; i += 1) {
    const blockStartCol = SETRA_DAILY_REPORT.START_COL + i * SETRA_DAILY_REPORT.BLOCK_WIDTH;
    hkaCells.push(setraDailyReportColToLetter_(blockStartCol));
    jtCells.push(setraDailyReportColToLetter_(blockStartCol + 1));
    attCells.push(setraDailyReportColToLetter_(blockStartCol + 2));

    const shipmentCol = setraDailyReportColToLetter_(blockStartCol + 4);
    if (!shipmentRangeStart) shipmentRangeStart = shipmentCol;
    shipmentRangeEnd = shipmentCol;
  }

  return {
    hkaCells: hkaCells,
    jtCells: jtCells,
    attCells: attCells,
    shipmentRangeStart: shipmentRangeStart,
    shipmentRangeEnd: shipmentRangeEnd,
  };
}

function setraDailyReportApplyShipmentDropdown_(sheet, participantCount, rowCount) {
  const rule = SpreadsheetApp.newDataValidation()
    .requireValueInList(SETRA_DAILY_REPORT.DROPDOWN_VALUES, true)
    .setAllowInvalid(true)
    .build();

  for (let i = 0; i < participantCount; i += 1) {
    const blockStartCol = SETRA_DAILY_REPORT.START_COL + i * SETRA_DAILY_REPORT.BLOCK_WIDTH;
    const shipmentCol = blockStartCol + 4;
    sheet.getRange(SETRA_DAILY_REPORT.DATA_START_ROW, shipmentCol, rowCount, 1).setDataValidation(rule);
  }
}

function setraDailyReportClearDataValidationForCells_(sheet, a1List) {
  (a1List || []).forEach(function (a1) {
    sheet.getRange(a1).clearDataValidations();
  });
}

function setraDailyReportResetRowBackground_(sheet, startRow, rowCount, startCol, endCol) {
  const colCount = endCol - startCol + 1;
  const backgrounds = Array.from({ length: rowCount }, function () {
    return Array.from({ length: colCount }, function () { return SETRA_DAILY_REPORT.DEFAULT_ROW_BACKGROUND; });
  });

  sheet.getRange(startRow, startCol, rowCount, colCount).setBackgrounds(backgrounds);
}

function setraDailyReportApplySundayRowBackground_(sheet, sundayRows, startRow, rowCount, startCol, endCol) {
  const colCount = endCol - startCol + 1;
  const sundayRowMap = {};
  (sundayRows || []).forEach(function (row) { sundayRowMap[row] = true; });

  const backgrounds = [];
  for (let r = 0; r < rowCount; r += 1) {
    const sheetRow = startRow + r;
    const background = sundayRowMap[sheetRow] ? SETRA_DAILY_REPORT.SUNDAY_ROW_BACKGROUND : SETRA_DAILY_REPORT.DEFAULT_ROW_BACKGROUND;
    backgrounds.push(Array.from({ length: colCount }, function () { return background; }));
  }

  sheet.getRange(startRow, startCol, rowCount, colCount).setBackgrounds(backgrounds);
}

function setraDailyReportBuildHkaFormula_(shipmentA1) {
  const normalizedShipment = 'TRIM(UPPER(TO_TEXT(' + shipmentA1 + ')))';
  const nonHkaChecks = SETRA_DAILY_REPORT.NON_HKA_VALUES
    .map(function (value) { return normalizedShipment + '="' + value + '"'; })
    .join(';');

  return '=IF(' + normalizedShipment + '="";"";IF(OR(' + nonHkaChecks + ');"";1))';
}

function setraDailyReportFormatData_(sheet, participantCount) {
  const numberRanges = [];
  const percentRanges = [];
  const shipmentRanges = [];

  for (let i = 0; i < participantCount; i += 1) {
    const blockStartCol = SETRA_DAILY_REPORT.START_COL + i * SETRA_DAILY_REPORT.BLOCK_WIDTH;
    const hkaCol = blockStartCol;
    const jtCol = blockStartCol + 1;
    const attCol = blockStartCol + 2;
    const percentCol = blockStartCol + 3;
    const shipmentCol = blockStartCol + 4;

    numberRanges.push(
      setraDailyReportColToLetter_(hkaCol) + SETRA_DAILY_REPORT.DATA_START_ROW + ':' + setraDailyReportColToLetter_(hkaCol) + SETRA_DAILY_REPORT.DATA_END_ROW,
      setraDailyReportColToLetter_(jtCol) + SETRA_DAILY_REPORT.DATA_START_ROW + ':' + setraDailyReportColToLetter_(jtCol) + SETRA_DAILY_REPORT.DATA_END_ROW,
      setraDailyReportColToLetter_(attCol) + SETRA_DAILY_REPORT.DATA_START_ROW + ':' + setraDailyReportColToLetter_(attCol) + SETRA_DAILY_REPORT.DATA_END_ROW
    );

    percentRanges.push(setraDailyReportColToLetter_(percentCol) + SETRA_DAILY_REPORT.DATA_START_ROW + ':' + setraDailyReportColToLetter_(percentCol) + SETRA_DAILY_REPORT.DATA_END_ROW);
    shipmentRanges.push(setraDailyReportColToLetter_(shipmentCol) + SETRA_DAILY_REPORT.DATA_START_ROW + ':' + setraDailyReportColToLetter_(shipmentCol) + SETRA_DAILY_REPORT.DATA_END_ROW);
  }

  if (numberRanges.length > 0) sheet.getRangeList(numberRanges).setNumberFormat('0');
  if (percentRanges.length > 0) sheet.getRangeList(percentRanges).setNumberFormat('0.00%');
  if (shipmentRanges.length > 0) sheet.getRangeList(shipmentRanges).setNumberFormat(SETRA_DAILY_REPORT.SHIPMENT_NUMBER_FORMAT);
}

function setraDailyReportNormalizeShipmentDisplay_(value) {
  const text = setraDailyReportText_(value);
  if (!text) return '';

  const compact = text.replace(/\s+/g, '');
  if (/^\d+$/.test(compact)) {
    return compact;
  }

  const upper = text.toUpperCase().replace(/\s+/g, ' ');
  return SETRA_DAILY_REPORT.STATUS_DISPLAY_MAP[upper] || upper;
}

function setraDailyReportGetRequiredSheet_(ss, sheetName) {
  const sheet = ss.getSheetByName(sheetName);
  if (!sheet) {
    throw new Error('Sheet tidak ditemukan: ' + sheetName);
  }
  return sheet;
}

function setraDailyReportGetAreaIdSafe_() {
  try {
    return setraGetAreaId_();
  } catch (error) {
    return '';
  }
}

function setraDailyReportNormalizeDate_(value, timezone) {
  const key = setraDailyReportDateKey_(value, timezone);
  if (!key) return null;

  const parts = key.split('-');
  return new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
}

function setraDailyReportDateKey_(value, timezone) {
  if (value instanceof Date && !isNaN(value.getTime())) {
    return Utilities.formatDate(value, timezone, 'yyyy-MM-dd');
  }

  if (typeof value === 'number' && value > 0) {
    const date = new Date(Math.round((value - 25569) * 86400 * 1000));
    if (!isNaN(date.getTime())) {
      return Utilities.formatDate(date, timezone, 'yyyy-MM-dd');
    }
  }

  if (typeof value === 'string' && value.trim()) {
    const text = value.trim();
    const yyyyMmDd = text.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})/);
    if (yyyyMmDd) {
      const date = new Date(Number(yyyyMmDd[1]), Number(yyyyMmDd[2]) - 1, Number(yyyyMmDd[3]));
      if (!isNaN(date.getTime())) return Utilities.formatDate(date, timezone, 'yyyy-MM-dd');
    }

    const ddMmYyyy = text.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})/);
    if (ddMmYyyy) {
      const date = new Date(Number(ddMmYyyy[3]), Number(ddMmYyyy[2]) - 1, Number(ddMmYyyy[1]));
      if (!isNaN(date.getTime())) return Utilities.formatDate(date, timezone, 'yyyy-MM-dd');
    }

    const parsed = new Date(text);
    if (!isNaN(parsed.getTime())) {
      return Utilities.formatDate(parsed, timezone, 'yyyy-MM-dd');
    }
  }

  return '';
}

function setraDailyReportDiffDaysInclusive_(startDate, endDate) {
  const start = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate()).getTime();
  const end = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate()).getTime();
  return Math.floor((end - start) / 86400000) + 1;
}

function setraDailyReportDayNameId_(date) {
  return ['MINGGU', 'SENIN', 'SELASA', 'RABU', 'KAMIS', 'JUMAT', 'SABTU'][date.getDay()];
}

function setraDailyReportMakeShipmentKey_(participantKey, dateKey) {
  return participantKey + '||' + dateKey;
}

function setraDailyReportHeaderKey_(value) {
  return setraDailyReportText_(value).toLowerCase().replace(/\s+/g, '_');
}

function setraDailyReportName_(value) {
  return setraDailyReportText_(value).toUpperCase().replace(/\s+/g, ' ');
}

function setraDailyReportKey_(value) {
  return setraDailyReportText_(value).toLowerCase().replace(/\s+/g, ' ');
}

function setraDailyReportText_(value) {
  return String(value === null || value === undefined ? '' : value).trim();
}

function setraDailyReportIsFalse_(value) {
  if (value === false) return true;
  const text = setraDailyReportText_(value).toLowerCase();
  return text === 'false' || text === '0' || text === 'nonaktif';
}

function setraDailyReportIsNumeric_(value) {
  if (typeof value === 'number' && !isNaN(value)) return true;
  const text = setraDailyReportText_(value);
  if (!text) return false;
  return !isNaN(Number(text.replace(/\./g, '').replace(',', '.')));
}

function setraDailyReportToNumber_(value) {
  if (typeof value === 'number') return value;
  const number = Number(setraDailyReportText_(value).replace(/\./g, '').replace(',', '.'));
  return isNaN(number) ? 0 : number;
}

function setraDailyReportColToLetter_(column) {
  let temp = '';
  let letter = '';

  while (column > 0) {
    temp = (column - 1) % 26;
    letter = String.fromCharCode(temp + 65) + letter;
    column = (column - temp - 1) / 26;
  }

  return letter;
}

function setraDailyReportCellA1_(row, column) {
  return setraDailyReportColToLetter_(column) + row;
}
