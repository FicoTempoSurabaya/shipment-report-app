/**
 * SETRA - Rekonsil Sheet Automation
 * File: 07_Rekonsil.gs
 * Scope: rebuild sheet "Rekonsil" otomatis saat C1/C2 diubah.
 *
 * Struktur output:
 * - C1 = Tanggal Mulai
 * - C2 = Tanggal Selesai
 * - A1:D8 tidak dibersihkan/tidak ditulis ulang oleh script ini.
 * - E5:kanan = nik_kerja regular, kosong untuk freelance.
 * - E6:kanan = nama_lengkap regular, lalu nama_freelance.
 * - E7:kanan = regular/freelance.
 * - A9:D bawah = No, Tanggal, Hari, jumlah shipment_code aktif 10 digit.
 * - Baris 8 dipertahankan sebagai separator/freeze pribadi.
 * - Setelah baris data tanggal ditambahkan 1 baris pemisah tinggi 7, lalu baris HK.
 * - E9:kanan bawah = shipment_code sesuai tanggal dan user/freelance.
 */

const SETRA_REKONSIL = Object.freeze({
  SHEET_NAME: 'Rekonsil',
  START_DATE_A1: 'C1',
  END_DATE_A1: 'C2',
  PRESERVE_RANGE_A1: 'A1:D8',
  FREEZE_ROW: 8,
  SEPARATOR_ROW_HEIGHT: 7,
  HEADER_NIK_ROW: 5,
  HEADER_NAME_ROW: 6,
  HEADER_STATUS_ROW: 7,
  DATA_START_ROW: 9,
  DYNAMIC_START_COLUMN: 5, // E
  HEADER_BG: '#305496',
  HEADER_FG: '#ffffff',
  ERROR_BG: '#ea4335',
  SUMMARY_BG: '#cccccc',
  ACTIVE_CODE_REGEX: /^\d{10}$/,
  MAX_RANGE_DAYS: 31,
});

/**
 * Trigger otomatis Google Sheets.
 * Berjalan saat C1 atau C2 pada sheet Rekonsil diedit manual/paste.
 */
function onEdit(e) {
  if (!e || !e.range) return;

  const range = e.range;
  const sheet = range.getSheet();

  if (sheet.getName() !== SETRA_REKONSIL.SHEET_NAME) return;
  if (!setraRekonsilEditedDateCells_(range)) return;

  setraRefreshRekonsil();
}

/**
 * Bisa dijalankan manual dari Apps Script editor/menu jika diperlukan.
 */
function setraRefreshRekonsil() {
  const lock = LockService.getDocumentLock();

  if (!lock.tryLock(30000)) {
    setraGetSpreadsheet_().toast('Rekonsil sedang diproses. Coba lagi setelah proses sebelumnya selesai.', 'Setra', 5);
    return;
  }

  try {
    const spreadsheet = setraGetSpreadsheet_();
    const sheet = setraGetSheet_(SETRA_REKONSIL.SHEET_NAME);
    const validation = setraValidateRekonsilDates_(sheet);

    if (!validation.ok) {
      spreadsheet.toast('Rekonsil tidak dijalankan: ' + validation.message, 'Setra', 8);
      return;
    }

    const context = setraBuildRekonsilContext_(validation.startDate, validation.endDate);
    setraClearRekonsilOutput_(sheet);
    setraWriteRekonsilOutput_(sheet, context);

    spreadsheet.toast('Rekonsil selesai diperbarui.', 'Setra', 5);
  } catch (error) {
    setraGetSpreadsheet_().toast('Rekonsil gagal: ' + (error && error.message ? error.message : String(error)), 'Setra', 8);
    throw error;
  } finally {
    lock.releaseLock();
  }
}

function setraRekonsilEditedDateCells_(range) {
  const rowStart = range.getRow();
  const rowEnd = rowStart + range.getNumRows() - 1;
  const colStart = range.getColumn();
  const colEnd = colStart + range.getNumColumns() - 1;

  return rowStart <= 2 && rowEnd >= 1 && colStart <= 3 && colEnd >= 3;
}

function setraValidateRekonsilDates_(sheet) {
  const startDate = setraRekonsilNormalizeDate_(sheet.getRange(SETRA_REKONSIL.START_DATE_A1).getValue());
  const endDate = setraRekonsilNormalizeDate_(sheet.getRange(SETRA_REKONSIL.END_DATE_A1).getValue());

  if (!startDate || !endDate) {
    return { ok: false, message: 'Tanggal Mulai C1 dan Tanggal Selesai C2 wajib berupa tanggal valid.' };
  }

  if (endDate.getTime() <= startDate.getTime()) {
    return { ok: false, message: 'Tanggal Selesai C2 harus lebih besar dari Tanggal Mulai C1.' };
  }

  const dayCount = setraRekonsilDiffDaysInclusive_(startDate, endDate);

  if (dayCount > SETRA_REKONSIL.MAX_RANGE_DAYS) {
    return { ok: false, message: 'Rentang tanggal maksimal ' + SETRA_REKONSIL.MAX_RANGE_DAYS + ' hari. Rentang saat ini ' + dayCount + ' hari.' };
  }

  return {
    ok: true,
    message: '',
    startDate: startDate,
    endDate: endDate,
    dayCount: dayCount,
  };
}

function setraBuildRekonsilContext_(startDate, endDate) {
  const areaId = setraRekonsilGetAreaIdSafe_();
  const slaArea = setraRekonsilGetSlaArea_(areaId);
  const usersIndex = setraRekonsilReadUsersIndex_(areaId);
  const shipmentRows = setraRekonsilReadShipmentRows_(areaId, startDate, endDate, usersIndex);
  const participants = setraRekonsilBuildParticipants_(shipmentRows, usersIndex);
  const participantIndex = setraRekonsilBuildParticipantIndex_(participants);
  const dates = setraRekonsilBuildDateList_(startDate, endDate);
  const codeGrid = setraRekonsilBuildCodeGrid_(dates, participants, participantIndex, shipmentRows);

  return {
    areaId: areaId,
    slaArea: slaArea,
    usersIndex: usersIndex,
    shipmentRows: shipmentRows,
    participants: participants,
    dates: dates,
    codeGrid: codeGrid,
  };
}

function setraRekonsilGetAreaIdSafe_() {
  try {
    return setraGetAreaId_();
  } catch (error) {
    return '';
  }
}

function setraRekonsilGetSlaArea_(areaId) {
  if (!areaId) return '';

  const sheet = setraGetSheet_(SETRA.SHEETS.AREA);
  const map = setraGetHeaderMap_(sheet);
  const lastRow = sheet.getLastRow();

  if (!map.area_id || !map.sla_area || lastRow < SETRA.DATA_START_ROW) return '';

  const values = sheet.getRange(SETRA.DATA_START_ROW, 1, lastRow - SETRA.DATA_START_ROW + 1, sheet.getLastColumn()).getValues();

  for (let i = 0; i < values.length; i++) {
    const rowAreaId = setraNormalizeText_(values[i][map.area_id - 1]);

    if (rowAreaId === areaId) {
      const value = values[i][map.sla_area - 1];
      return value === '' || value === null || value === undefined ? '' : Number(value);
    }
  }

  return '';
}

function setraRekonsilReadUsersIndex_(areaId) {
  const sheet = setraGetSheet_(SETRA.SHEETS.USERS);
  const map = setraGetHeaderMap_(sheet);
  const lastRow = sheet.getLastRow();
  const result = {
    byNik: {},
    nikByName: {},
  };

  if (!map.nik_kerja || !map.nama_lengkap || lastRow < SETRA.DATA_START_ROW) {
    return result;
  }

  const columnCount = sheet.getLastColumn();
  const values = sheet.getRange(SETRA.DATA_START_ROW, 1, lastRow - SETRA.DATA_START_ROW + 1, columnCount).getValues();
  const displayValues = sheet.getRange(SETRA.DATA_START_ROW, 1, lastRow - SETRA.DATA_START_ROW + 1, columnCount).getDisplayValues();

  values.forEach(function (rawRow, index) {
    const displayRow = displayValues[index];
    const nik = setraNormalizeText_(displayRow[map.nik_kerja - 1]);
    const name = setraNormalizeText_(displayRow[map.nama_lengkap - 1]);
    const rowAreaId = map.area_id ? setraNormalizeText_(displayRow[map.area_id - 1]) : '';
    const isActiveValue = map.is_active ? rawRow[map.is_active - 1] : true;

    if (!nik || !name) return;
    if (areaId && rowAreaId && rowAreaId !== areaId) return;
    if (setraRekonsilIsFalse_(isActiveValue)) return;

    result.byNik[nik] = {
      nik: nik,
      name: name,
      areaId: rowAreaId,
    };

    const nameKey = setraNormalizeKey_(name);
    if (!result.nikByName[nameKey]) {
      result.nikByName[nameKey] = [];
    }
    result.nikByName[nameKey].push(nik);
  });

  return result;
}

function setraRekonsilReadShipmentRows_(areaId, startDate, endDate, usersIndex) {
  const sheet = setraGetSheet_(SETRA.SHEETS.SHIPMENTS);
  const map = setraGetHeaderMap_(sheet);
  const lastRow = sheet.getLastRow();
  const rows = [];

  if (!map.tanggal_shipment || !map.shipment_code || lastRow < SETRA.DATA_START_ROW) {
    return rows;
  }

  const columnCount = sheet.getLastColumn();
  const values = sheet.getRange(SETRA.DATA_START_ROW, 1, lastRow - SETRA.DATA_START_ROW + 1, columnCount).getValues();
  const displayValues = sheet.getRange(SETRA.DATA_START_ROW, 1, lastRow - SETRA.DATA_START_ROW + 1, columnCount).getDisplayValues();
  const startTime = startDate.getTime();
  const endTime = endDate.getTime();

  values.forEach(function (rawRow, index) {
    const displayRow = displayValues[index];
    const dateValue = setraRekonsilNormalizeDate_(rawRow[map.tanggal_shipment - 1] || displayRow[map.tanggal_shipment - 1]);

    if (!dateValue) return;
    if (dateValue.getTime() < startTime || dateValue.getTime() > endTime) return;

    const rowAreaId = map.area_id ? setraNormalizeText_(displayRow[map.area_id - 1]) : '';
    if (areaId && rowAreaId && rowAreaId !== areaId) return;

    const shipmentCode = setraNormalizeText_(displayRow[map.shipment_code - 1]);
    if (!shipmentCode) return;

    const statusKerja = map.status_kerja ? setraNormalizeKey_(displayRow[map.status_kerja - 1]) : '';
    const rawIsFreelance = map.__is_freelance ? rawRow[map.__is_freelance - 1] : '';
    const namaFreelance = map.nama_freelance ? setraNormalizeText_(displayRow[map.nama_freelance - 1]) : '';
    const namaLengkap = map.nama_lengkap ? setraNormalizeText_(displayRow[map.nama_lengkap - 1]) : '';
    const explicitNik = map.nik_kerja ? setraNormalizeText_(displayRow[map.nik_kerja - 1]) : '';
    const isFreelance = statusKerja === 'freelance' || setraRekonsilIsTrue_(rawIsFreelance) || !!namaFreelance;

    let nik = explicitNik;
    if (!isFreelance && !nik && namaLengkap) {
      nik = setraRekonsilResolveNikByName_(namaLengkap, usersIndex);
    }

    if (!isFreelance && !nik) return;
    if (isFreelance && !namaFreelance) return;

    const name = isFreelance
      ? namaFreelance
      : (usersIndex.byNik[nik] && usersIndex.byNik[nik].name ? usersIndex.byNik[nik].name : namaLengkap);

    rows.push({
      dateKey: setraRekonsilDateKey_(dateValue),
      date: dateValue,
      isFreelance: isFreelance,
      status: isFreelance ? 'freelance' : 'regular',
      nik: isFreelance ? '' : nik,
      name: name,
      shipmentCode: shipmentCode,
    });
  });

  return rows;
}

function setraRekonsilBuildParticipants_(shipmentRows, usersIndex) {
  const regularByNik = {};
  const freelanceByName = {};

  shipmentRows.forEach(function (row) {
    if (row.isFreelance) {
      const nameKey = setraNormalizeKey_(row.name);
      if (!nameKey) return;

      if (!freelanceByName[nameKey]) {
        freelanceByName[nameKey] = {
          status: 'freelance',
          nik: '',
          name: row.name,
          key: 'freelance|' + nameKey,
        };
      }
      return;
    }

    if (!row.nik) return;
    if (!regularByNik[row.nik]) {
      regularByNik[row.nik] = {
        status: 'regular',
        nik: row.nik,
        name: usersIndex.byNik[row.nik] && usersIndex.byNik[row.nik].name ? usersIndex.byNik[row.nik].name : row.name,
        key: 'regular|' + row.nik,
      };
    }
  });

  const regular = Object.keys(regularByNik)
    .map(function (nik) { return regularByNik[nik]; })
    .sort(function (a, b) { return String(a.nik).localeCompare(String(b.nik), 'id', { numeric: true, sensitivity: 'base' }); });

  const freelance = Object.keys(freelanceByName)
    .map(function (nameKey) { return freelanceByName[nameKey]; })
    .sort(function (a, b) { return String(a.name).localeCompare(String(b.name), 'id', { numeric: true, sensitivity: 'base' }); });

  return regular.concat(freelance);
}

function setraRekonsilBuildParticipantIndex_(participants) {
  const result = {};

  participants.forEach(function (participant, index) {
    result[participant.key] = index;
  });

  return result;
}

function setraRekonsilBuildDateList_(startDate, endDate) {
  const dates = [];
  const cursor = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate());

  while (cursor.getTime() <= endDate.getTime()) {
    dates.push(new Date(cursor.getFullYear(), cursor.getMonth(), cursor.getDate()));
    cursor.setDate(cursor.getDate() + 1);
  }

  return dates;
}

function setraRekonsilBuildCodeGrid_(dates, participants, participantIndex, shipmentRows) {
  const dateIndex = {};
  const grid = dates.map(function (date, index) {
    dateIndex[setraRekonsilDateKey_(date)] = index;
    return participants.map(function () { return ''; });
  });

  shipmentRows.forEach(function (row) {
    const dateRowIndex = dateIndex[row.dateKey];
    const participantKey = row.isFreelance ? 'freelance|' + setraNormalizeKey_(row.name) : 'regular|' + row.nik;
    const participantColIndex = participantIndex[participantKey];

    if (dateRowIndex === undefined || participantColIndex === undefined) return;

    const currentValue = grid[dateRowIndex][participantColIndex];
    grid[dateRowIndex][participantColIndex] = currentValue ? currentValue + ', ' + row.shipmentCode : row.shipmentCode;
  });

  return grid;
}

function setraClearRekonsilOutput_(sheet) {
  const maxRows = sheet.getMaxRows();
  const maxColumns = sheet.getMaxColumns();
  const dynamicStartCol = SETRA_REKONSIL.DYNAMIC_START_COLUMN;

  setraClearLegacyRekonsilStaticHeader_(sheet);

  // Area pribadi A1:D8, termasuk baris 8 sebagai separator/freeze, tidak disentuh.
  if (maxRows >= SETRA_REKONSIL.DATA_START_ROW) {
    const rowCount = maxRows - SETRA_REKONSIL.DATA_START_ROW + 1;

    sheet.getRange(SETRA_REKONSIL.DATA_START_ROW, 1, rowCount, Math.min(4, maxColumns))
      .breakApart()
      .clearContent()
      .clearFormat()
      .clearDataValidations()
      .clearNote();

    if (maxColumns >= dynamicStartCol) {
      const dynamicColumnCount = maxColumns - dynamicStartCol + 1;
      sheet.getRange(SETRA_REKONSIL.DATA_START_ROW, dynamicStartCol, rowCount, dynamicColumnCount)
        .breakApart()
        .clearContent()
        .clearFormat()
        .clearDataValidations()
        .clearNote();
    }
  }

  // Header dinamis E5:kanan sampai E7:kanan boleh dibangun ulang. Baris 8 tetap tidak disentuh.
  if (maxColumns >= dynamicStartCol) {
    const dynamicColumnCount = maxColumns - dynamicStartCol + 1;
    sheet.getRange(SETRA_REKONSIL.HEADER_NIK_ROW, dynamicStartCol, 3, dynamicColumnCount)
      .breakApart()
      .clearContent()
      .clearFormat()
      .clearDataValidations()
      .clearNote();
  }
}

function setraClearLegacyRekonsilStaticHeader_(sheet) {
  const legacyHeaderRange = sheet.getRange(SETRA_REKONSIL.FREEZE_ROW, 1, 1, 4);
  const values = legacyHeaderRange.getDisplayValues()[0].map(function (value) {
    return setraNormalizeKey_(value);
  });

  if (values.join('|') === 'no|tanggal|hari|jumlah') {
    legacyHeaderRange
      .breakApart()
      .clearContent()
      .clearFormat()
      .clearDataValidations()
      .clearNote();
  }
}

function setraWriteRekonsilOutput_(sheet, context) {
  const participants = context.participants;
  const dates = context.dates;
  const codeGrid = context.codeGrid;
  const participantCount = participants.length;
  const dateCount = dates.length;
  const dynamicStartCol = SETRA_REKONSIL.DYNAMIC_START_COLUMN;
  const lastColumn = Math.max(4, dynamicStartCol + participantCount - 1);
  const separatorRow = SETRA_REKONSIL.DATA_START_ROW + dateCount;
  const summaryRow = separatorRow + 1;

  setraEnsureRekonsilSize_(sheet, summaryRow, lastColumn);

  if (participantCount > 0) {
    const nikRow = participants.map(function (participant) { return participant.nik; });
    const nameRow = participants.map(function (participant) { return participant.name; });
    const statusRow = participants.map(function (participant) { return participant.status; });

    sheet.getRange(SETRA_REKONSIL.HEADER_NIK_ROW, dynamicStartCol, 1, participantCount).setValues([nikRow]);
    sheet.getRange(SETRA_REKONSIL.HEADER_NAME_ROW, dynamicStartCol, 1, participantCount).setValues([nameRow]);
    sheet.getRange(SETRA_REKONSIL.HEADER_STATUS_ROW, dynamicStartCol, 1, participantCount).setValues([statusRow]);
    sheet.getRange(SETRA_REKONSIL.HEADER_NIK_ROW, dynamicStartCol, 3, participantCount)
      .setBackground(SETRA_REKONSIL.HEADER_BG)
      .setFontColor(SETRA_REKONSIL.HEADER_FG)
      .setFontWeight('bold')
      .setHorizontalAlignment('center')
      .setVerticalAlignment('middle')
      .setWrap(true);
  }

  const staticRows = [];
  const activeCountsByParticipant = participants.map(function () { return 0; });

  for (let i = 0; i < dateCount; i++) {
    const rowCodes = codeGrid[i] || [];
    let activeCount = 0;

    for (let c = 0; c < rowCodes.length; c++) {
      const codeCount = setraRekonsilCountActiveCodes_(rowCodes[c]);
      activeCount += codeCount;
      activeCountsByParticipant[c] += codeCount;
    }

    staticRows.push([
      i + 1,
      dates[i],
      setraRekonsilGetIndonesianDayName_(dates[i]),
      activeCount,
    ]);
  }

  if (staticRows.length > 0) {
    sheet.getRange(SETRA_REKONSIL.DATA_START_ROW, 1, staticRows.length, 4).setValues(staticRows);
    sheet.getRange(SETRA_REKONSIL.DATA_START_ROW, 2, staticRows.length, 1).setNumberFormat('dd/mm/yyyy');
    sheet.getRange(SETRA_REKONSIL.DATA_START_ROW, 4, staticRows.length, 1).setNumberFormat('0');
  }

  if (participantCount > 0 && dateCount > 0) {
    sheet.getRange(SETRA_REKONSIL.DATA_START_ROW, dynamicStartCol, dateCount, participantCount).setValues(codeGrid);
    sheet.getRange(SETRA_REKONSIL.DATA_START_ROW, dynamicStartCol, dateCount, participantCount).setNumberFormat('@');
  }

  setraWriteRekonsilSeparatorRow_(sheet, separatorRow, lastColumn);
  setraWriteRekonsilSummaryRow_(sheet, summaryRow, lastColumn, context.slaArea, staticRows, activeCountsByParticipant);
  setraFormatRekonsilOutput_(sheet, dateCount, participantCount, lastColumn);
}

function setraWriteRekonsilSeparatorRow_(sheet, separatorRow, lastColumn) {
  sheet.getRange(separatorRow, 1, 1, lastColumn)
    .breakApart()
    .clearContent()
    .clearFormat()
    .clearDataValidations()
    .clearNote()
    .setVerticalAlignment('middle');
  sheet.setRowHeight(separatorRow, SETRA_REKONSIL.SEPARATOR_ROW_HEIGHT);
}

function setraWriteRekonsilSummaryRow_(sheet, summaryRow, lastColumn, slaArea, staticRows, activeCountsByParticipant) {
  const totalActive = staticRows.reduce(function (sum, row) {
    return sum + Number(row[3] || 0);
  }, 0);

  sheet.getRange(summaryRow, 1).setValue('HK');
  sheet.getRange(summaryRow, 2, 1, 2).merge().setValue(slaArea === '' ? '' : Number(slaArea));
  sheet.getRange(summaryRow, 4).setValue(totalActive);

  if (activeCountsByParticipant.length > 0) {
    sheet.getRange(summaryRow, SETRA_REKONSIL.DYNAMIC_START_COLUMN, 1, activeCountsByParticipant.length).setValues([activeCountsByParticipant]);
  }

  sheet.getRange(summaryRow, 1, 1, lastColumn)
    .setBackground(SETRA_REKONSIL.SUMMARY_BG)
    .setFontWeight('bold')
    .setHorizontalAlignment('center')
    .setVerticalAlignment('middle')
    .setFontColor('#000000')
    .setNumberFormat('0');
}

function setraFormatRekonsilOutput_(sheet, dateCount, participantCount, lastColumn) {
  const dataStartRow = SETRA_REKONSIL.DATA_START_ROW;
  const separatorRow = dataStartRow + dateCount;
  const summaryRow = separatorRow + 1;

  sheet.getRange(1, 3, 2, 1)
    .setNumberFormat('dd/mm/yyyy')
    .setVerticalAlignment('middle');

  if (participantCount > 0) {
    sheet.getRange(SETRA_REKONSIL.HEADER_NIK_ROW, SETRA_REKONSIL.DYNAMIC_START_COLUMN, 3, participantCount)
      .setBorder(true, true, true, true, true, true)
      .setVerticalAlignment('middle');
  }

  if (dateCount > 0) {
    sheet.getRange(dataStartRow, 1, dateCount, lastColumn)
      .setBorder(true, true, true, true, true, true)
      .setHorizontalAlignment('center')
      .setVerticalAlignment('middle')
      .setFontColor('#000000')
      .setBackground(null);

    setraApplyRekonsilSundayRedRows_(sheet, dateCount, lastColumn);
  }

  sheet.getRange(separatorRow, 1, 1, lastColumn)
    .setVerticalAlignment('middle')
    .setBackground(null);

  sheet.getRange(summaryRow, 1, 1, lastColumn)
    .setBorder(true, true, true, true, true, true)
    .setHorizontalAlignment('center')
    .setVerticalAlignment('middle');

  sheet.setFrozenRows(SETRA_REKONSIL.FREEZE_ROW);
  sheet.setFrozenColumns(4);

  sheet.setColumnWidth(1, 48);
  sheet.setColumnWidth(2, 110);
  sheet.setColumnWidth(3, 95);
  sheet.setColumnWidth(4, 75);

  if (participantCount > 0) {
    for (let col = SETRA_REKONSIL.DYNAMIC_START_COLUMN; col <= lastColumn; col++) {
      sheet.setColumnWidth(col, 115);
    }
  }
}

function setraApplyRekonsilSundayRedRows_(sheet, dateCount, lastColumn) {
  if (dateCount <= 0) return;

  const dayNames = sheet.getRange(SETRA_REKONSIL.DATA_START_ROW, 3, dateCount, 1).getValues();

  for (let i = 0; i < dayNames.length; i++) {
    const rowNumber = SETRA_REKONSIL.DATA_START_ROW + i;
    const dayName = setraNormalizeKey_(dayNames[i][0]);

    if (dayName === 'minggu') {
      sheet.getRange(rowNumber, 1, 1, lastColumn)
        .setBackground(SETRA_REKONSIL.ERROR_BG)
        .setFontColor('#ffffff');
    }
  }
}

function setraEnsureRekonsilSize_(sheet, requiredRows, requiredColumns) {
  if (sheet.getMaxRows() < requiredRows) {
    sheet.insertRowsAfter(sheet.getMaxRows(), requiredRows - sheet.getMaxRows());
  }

  if (sheet.getMaxColumns() < requiredColumns) {
    sheet.insertColumnsAfter(sheet.getMaxColumns(), requiredColumns - sheet.getMaxColumns());
  }
}

function setraRekonsilCountActiveCodes_(value) {
  return String(value || '')
    .split(/[,;\n]/)
    .map(function (code) { return code.trim(); })
    .filter(function (code) { return SETRA_REKONSIL.ACTIVE_CODE_REGEX.test(code); })
    .length;
}

function setraRekonsilResolveNikByName_(name, usersIndex) {
  const candidates = usersIndex.nikByName[setraNormalizeKey_(name)] || [];
  return candidates.length === 1 ? candidates[0] : '';
}

function setraRekonsilNormalizeDate_(value) {
  if (Object.prototype.toString.call(value) === '[object Date]' && !isNaN(value.getTime())) {
    return new Date(value.getFullYear(), value.getMonth(), value.getDate());
  }

  const text = setraNormalizeText_(value);
  if (!text) return null;

  let match = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (match) {
    return setraRekonsilBuildValidDate_(Number(match[1]), Number(match[2]), Number(match[3]));
  }

  match = text.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);
  if (match) {
    return setraRekonsilBuildValidDate_(Number(match[3]), Number(match[2]), Number(match[1]));
  }

  match = text.match(/^(\d{1,2})-(\d{1,2})-(\d{4})/);
  if (match) {
    return setraRekonsilBuildValidDate_(Number(match[3]), Number(match[2]), Number(match[1]));
  }

  const parsed = new Date(text);
  if (!isNaN(parsed.getTime())) {
    return new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
  }

  return null;
}

function setraRekonsilBuildValidDate_(year, month, day) {
  if (!year || !month || !day) return null;

  const date = new Date(year, month - 1, day);
  if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) {
    return null;
  }

  return date;
}

function setraRekonsilDateKey_(date) {
  return Utilities.formatDate(date, setraGetTimezone_(), 'yyyy-MM-dd');
}

function setraRekonsilDiffDaysInclusive_(startDate, endDate) {
  const oneDayMs = 24 * 60 * 60 * 1000;
  return Math.floor((endDate.getTime() - startDate.getTime()) / oneDayMs) + 1;
}

function setraRekonsilGetIndonesianDayName_(date) {
  const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
  return days[date.getDay()];
}

function setraRekonsilIsTrue_(value) {
  if (value === true) return true;
  const text = setraNormalizeKey_(value);
  return text === 'true' || text === '1' || text === 'yes' || text === 'ya';
}

function setraRekonsilIsFalse_(value) {
  if (value === false) return true;
  const text = setraNormalizeKey_(value);
  return text === 'false' || text === '0' || text === 'no' || text === 'tidak';
}
