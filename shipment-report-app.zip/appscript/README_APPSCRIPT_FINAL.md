# Setra Apps Script Final

Isi folder ini adalah Apps Script final untuk `Master_Template_FINAL.xlsx`.

Perubahan utama:
- Menu `Setra` dengan submenu `Shipments > update`, `Shipments > fetching`, dan `Shipments > hapus data tercentang`.
- Update shipments bersifat incremental: hanya baris baru/berubah yang dikirim ke database.
- Fetching shipments bersifat incremental: memakai `updated_after`, cursor, dan `__row_hash`.
- Kolom B sheet `shipments` dipakai sebagai checkbox hapus permanen.
- Baris yang dicentang berubah merah.
- Proses hapus memakai modal warning, hard delete database dulu, lalu hapus row spreadsheet.
- Kolom `alasan` memakai dropdown/list alasan dan tetap disimpan sebagai teks biasa.
- `Report_Performance` rebuild sheet `Daily_Report` dari sheet `shipments` dan `users`.
