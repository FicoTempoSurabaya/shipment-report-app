# Setra Apps Script - Database Sync Stage

Fokus versi ini: koneksi database lebih dulu. Sheet `Reconciliation`, `Daily_Report`, dan `Performance` ditunda.

Menu aktif:

```txt
Setra
|- Users Checking
|- Date Locking
|- Shipments
|  |- Updating   (Database -> Spreadsheet, max 500 row per klik)
|  |- Fetching   (Spreadsheet -> Database, max 500 row pending per klik)
|  |- Deleting   (hapus permanen row tercentang dari database lalu spreadsheet)
|- Reconciliation (Tunda Dulu)
|- Performance (Tunda Dulu)
```

Prinsip:

- `_config` otomatis diisi oleh Apps Script/connect flow, kecuali `TEMPLATE_VERSION` dan `SUPERADMIN_EMAILS`.
- Sheet `area` disembunyikan dan diproteksi untuk `SUPERADMIN_EMAILS`.
- Semua kolom teknis `__...` disembunyikan dan diproses sistem.
- Tidak memakai `__row_hash`; diganti dengan `__sync_snapshot` berupa gabungan nilai kolom bisnis.
- `Shipments > Updating` memakai cursor `updated_at||shipment_id`, bukan grabbing dari awal setiap klik.
- `Shipments > Updating` juga mengecek batch `__shipment_id` yang sudah hilang dari database dan menghapusnya dari spreadsheet.
- `Shipments > Fetching` hanya mengirim row dengan `__sync_action=UPSERT` dan `__sync_status=PENDING/ERROR`.
- `Shipments > Deleting` hanya bisa untuk row yang sudah punya `__shipment_id`.
- Dropdown/checkbox/validasi tidak dibawa dari file template; semuanya dipasang oleh Apps Script saat runtime.
